
--kredit
insert into kredit
values (1, 'naziv1', 'oznaka1', 'opis1');

insert into kredit
values (2, 'naziv2', 'oznaka2', 'opis2');

insert into kredit
values (-100, 'zaTestiranje', 'testOznaka', 'testOpis');

--tip racuna
insert into tip_racuna
values (1, 'tip1', 'oznaka1', 'opis1');

insert into tip_racuna
values (2, 'tip2', 'oznaka2', 'opis2');

insert into tip_racuna
values (-100, 'Test tip', 'Test oznaka', 'Test opis');

--klijent

insert into klijent
values (1, 'steva', 'jobic', 532, 1);

insert into klijent
values (2, 'mita', 'ruzic', 421, 2);

insert into klijent
values (-100, 'test ime', 'test prezime', 777, -100);

--racun
insert into racun
values (1, 'petrovici', 'oznaka1', 'neki racun od petrovica', 1,1);

insert into racun
values (2, 'pterodaktilovic', 'oznaka1', 'neki racun od dinosaurusa!', 2,2);

insert into racun
values (-100, 'test', 'test', 'test', -100, -100);